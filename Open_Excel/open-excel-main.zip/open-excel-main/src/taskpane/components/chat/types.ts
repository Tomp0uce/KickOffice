export type ChatTab = "chat" | "settings";
